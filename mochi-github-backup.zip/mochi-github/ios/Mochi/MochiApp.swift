import SwiftUI
import WebKit

@main
struct MochiApp: App {
    var body: some Scene { WindowGroup { MochiView().preferredColorScheme(.light) } }
}

struct MochiView: View {
    private let cream = Color(red: 1, green: 0.984, blue: 0.961)
    var body: some View {
        ZStack {
            cream.ignoresSafeArea()
            if let raw = Bundle.main.object(forInfoDictionaryKey: "MochiServerURL") as? String,
               let url = URL(string: raw), url.host != nil {
                MochiWebView(url: url).ignoresSafeArea(.container)
            } else {
                VStack(spacing: 16) {
                    Text("mochi.").font(.system(size: 42, weight: .semibold, design: .rounded))
                    Text("Connect your Mochi server").font(.title3)
                    Text("Set MOCHI_SERVER_URL in the project’s release configuration to your deployed HTTPS app address.")
                        .font(.body).multilineTextAlignment(.center)
                }.padding(30).foregroundStyle(Color(red: 0.25, green: 0.21, blue: 0.18))
            }
        }
    }
}

struct MochiWebView: UIViewRepresentable {
    let url: URL
    func makeCoordinator() -> Coordinator { Coordinator(origin: url) }
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.navigationDelegate = context.coordinator
        web.uiDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 1, green: 0.984, blue: 0.961, alpha: 1)
        web.scrollView.backgroundColor = web.backgroundColor
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = true
        web.load(URLRequest(url: url))
        return web
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let origin: URL
        init(origin: URL) { self.origin = origin }
        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = action.request.url else { decisionHandler(.cancel); return }
            if url.host == origin.host && url.scheme == origin.scheme && url.port == origin.port {
                decisionHandler(.allow)
            } else if action.navigationType == .linkActivated, ["https", "mailto", "tel"].contains(url.scheme ?? "") {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
            } else { decisionHandler(.cancel) }
        }
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if action.targetFrame == nil { webView.load(action.request) }
            return nil
        }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            if (error as NSError).code == NSURLErrorCancelled { return }
            let message = "Mochi couldn’t reach its server. Check your connection and reopen the app. For a local simulator preview, keep the Mac’s development server running."
            let alert = UIAlertController(title: "A little connection needed", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Try again", style: .default) { _ in webView.load(URLRequest(url: self.origin)) })
            webView.window?.rootViewController?.present(alert, animated: true)
        }
    }
}
