# Mochi for iPhone

This is an iPhone-only SwiftUI app shell using WKWebView to run the Mochi web app and its server APIs. It includes an app icon, portrait layout, persistent web storage/cookies, and an offline connection alert.

## Current status

- Browser preview has been set to 390 × 844 (iPhone size).
- The Swift app shell compiled with the installed Xcode 16.2 before the icon was added. The final simulator build including its asset catalog could not complete because no simulator runtime was available to the asset compiler. A device-target build hit the same asset-compiler runtime restriction. Running the simulator UI was not verified. Install an iPhone simulator runtime in Xcode, then build again.
- This is source for an Xcode project, not a signed IPA and not a TestFlight upload.
- The web app still needs a deployed, reachable HTTPS server. localhost on an iPhone refers to the iPhone, not this Mac.
- The installed Xcode 16.2 can build a local simulator preview. Apple's current upload guidance requires iOS apps built using Xcode 26 or later. Update Xcode before distributing.
- No Apple account, signing certificate, or API key is embedded here.

## View in the iPhone simulator

1. Unzip the project, then open Mochi.xcodeproj in Xcode.
2. Keep the Mochi web development server running on the Mac at http://127.0.0.1:5173.
3. Select the Mochi scheme and an installed iPhone simulator, then press Run.
4. If Xcode asks for a simulator runtime, install it from Xcode Settings → Components/Platforms (the label depends on Xcode version).

The Debug configuration points to the Mac's local web server. It is meant for the simulator; it will not connect from a physical iPhone. To test on a physical phone, use a hosted HTTPS server URL in Config/Debug.xcconfig and configure your Apple signing team.

## Prepare for TestFlight

1. Update Xcode to meet Apple's current upload requirements.
2. Deploy the Mochi web server with its database migrations and server-side OPENAI_API_KEY. Confirm that email signup, login, and chat work over HTTPS and that the server is reachable from the iOS app. A private hosting-platform login gate may require a separate native authentication integration; this wrapper only loads its configured origin. Hosting access settings have not been changed. The app shell does not bundle the server or its secrets.
3. In Config/Release.xcconfig, set MOCHI_SERVER_URL to your hosted URL. In an xcconfig file write https:/$()/your-real-domain so the double slash is not parsed as a comment.
4. Select the Mochi target → Signing & Capabilities. Choose your Apple Developer team and replace com.example.mochi with a unique bundle identifier you control.
5. Create the matching iOS app in App Store Connect with that bundle identifier.
6. Choose Any iOS Device / a generic iPhone device as the build destination, then Product → Archive.
7. In Organizer, choose Distribute App → App Store Connect → Upload. Complete signing and upload with your own account.
8. After Apple processes the build, open the app's TestFlight tab in App Store Connect, add the required test information, and add yourself as an internal tester. Complete any required review before inviting external testers.

The Release build intentionally fails while the hosted server URL is blank or a localhost/placeholder address. Simulator builds cannot be uploaded to TestFlight. Upload/review acceptance has not been verified.

## Data and accounts

The web server owns email/password authentication and AI requests. The app shell keeps normal WKWebView cookies and localStorage. Mood/session history is device-local, so browser history is not automatically transferred into the iPhone app. Profiles/accounts live in the server database. Deploying creates a separate database from this Mac's local preview unless data is migrated deliberately.

## Apple references

- Upload builds: https://developer.apple.com/help/app-store-connect/manage-builds/upload-builds/
- Beta testing and releases: https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases
