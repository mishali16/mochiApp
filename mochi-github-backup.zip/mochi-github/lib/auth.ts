import {randomBytes,scrypt,timingSafeEqual,createHash} from 'node:crypto';
import {cookies} from 'next/headers';
import {eq,gt,and,lte,sql} from 'drizzle-orm';
import {getDb} from '../db';
import {authSessions,authAttempts,users} from '../db/schema';
const cookieName='mochi_session';
const sessionAge=7*24*60*60;
export const noStore={'Cache-Control':'no-store'};
export const digest=(s:string)=>createHash('sha256').update(s).digest('hex');
export function sameOrigin(request:Request){return request.headers.get('origin')===new URL(request.url).origin}
export function passwordHash(password:string,salt:string){return new Promise<Buffer>((resolve,reject)=>scrypt(password,salt,64,{N:32768,r:8,p:3,maxmem:64*1024*1024},(e,key)=>e?reject(e):resolve(key)))}
export async function getAppUser(){const token=(await cookies()).get(cookieName)?.value;if(!token||!/^[a-f0-9]{64}$/.test(token))return null;const row=await getDb().select({userId:users.id,email:users.email}).from(authSessions).innerJoin(users,eq(authSessions.userId,users.id)).where(and(eq(authSessions.tokenHash,digest(token)),gt(authSessions.expires,Date.now()))).get();return row??null}
function cookieValue(request:Request,value:string,maxAge:number){return `${cookieName}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${!import.meta.env.DEV||new URL(request.url).protocol==='https:'?'; Secure':''}`}
export async function createSession(request:Request,userId:string){const token=randomBytes(32).toString('hex');const db=getDb();await db.delete(authSessions).where(lte(authSessions.expires,Date.now()));await db.insert(authSessions).values({tokenHash:digest(token),userId,expires:Date.now()+sessionAge*1000});return cookieValue(request,token,sessionAge)}
export async function endSession(request:Request){const token=(await cookies()).get(cookieName)?.value;if(token)await getDb().delete(authSessions).where(eq(authSessions.tokenHash,digest(token)));return cookieValue(request,'',0)}
export async function rateLimit(request:Request,email:string,mode:string){const db=getDb(),now=Date.now(),ip=request.headers.get('cf-connecting-ip')||'local';const bucket=digest(`${mode}:${ip}:${mode==='login'?email:''}`);const row=await db.insert(authAttempts).values({bucket,hits:1,resetAt:now+900000}).onConflictDoUpdate({target:authAttempts.bucket,set:{hits:sql`CASE WHEN ${authAttempts.resetAt} <= ${now} THEN 1 ELSE ${authAttempts.hits} + 1 END`,resetAt:sql`CASE WHEN ${authAttempts.resetAt} <= ${now} THEN ${now+900000} ELSE ${authAttempts.resetAt} END`}}).returning({hits:authAttempts.hits}).get();return row.hits<=10}
export async function authenticate(request:Request,mode:'signup'|'login'){
if(!sameOrigin(request))return Response.json({error:'Please use the form in Mochi.'},{status:403,headers:noStore});
try{const raw=await request.text();if(raw.length>4096)return Response.json({error:'Please use a shorter email and password.'},{status:413,headers:noStore});const body=JSON.parse(raw);const email=typeof body.email==='string'?body.email.trim().toLowerCase():'';const password=typeof body.password==='string'?body.password:'';if(email.length>254||!/^\S+@[^\s@]+\.[^\s@]+$/.test(email)||password.length>128||password.length<(mode==='signup'?15:1))return Response.json({error:mode==='signup'?'Enter a valid email and a password with at least 15 characters.':'Enter your email and password.'},{status:400,headers:noStore});if(!await rateLimit(request,email,mode))return Response.json({error:'Too many attempts. Please try again in 15 minutes.'},{status:429,headers:{...noStore,'Retry-After':'900'}});
const db=getDb();let user=await db.select().from(users).where(eq(users.email,email)).get();
if(mode==='signup'){if(user)return Response.json({error:'Unable to create this account. If you already signed up, please log in.'},{status:409,headers:noStore});const salt=randomBytes(16).toString('hex'),hash=(await passwordHash(password,salt)).toString('hex');user={id:crypto.randomUUID(),email,passwordHash:hash,salt};await db.insert(users).values(user)}else{const hash=await passwordHash(password,user?.salt||'dummy-account-salt');const expected=Buffer.from(user?.passwordHash||'0'.repeat(128),'hex');if(!user||!timingSafeEqual(hash,expected))return Response.json({error:'That email or password doesn’t match. Please try again.'},{status:401,headers:noStore})}
const cookie=await createSession(request,user.id);return Response.json({ok:true},{headers:{...noStore,'Set-Cookie':cookie}})
}catch{return Response.json({error:'We couldn’t connect to your account. Please try again.'},{status:503,headers:noStore})}}
