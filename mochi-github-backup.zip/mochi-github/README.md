# Mochi · a little room to breathe

An illustrated wellness app with four tabs, original reusable SVG characters, five accurately timed breathing exercises, local mood/session history, achievements, a journal, and a server-side AI companion route.

## Run

Requires Node 22.13+.

```sh
npm install
npm run dev
```

## Companion setup

Without a key, the app displays an honest setup state. Set OPENAI_API_KEY as a server environment secret; optionally set OPENAI_MODEL (default gpt-4.1-mini) and MOCHI_SYSTEM_PROMPT. For local Worker development, use an untracked .dev.vars file. For the hosted Site, use its runtime environment settings, then redeploy. Never use a NEXT_PUBLIC_ variable for the key.

POST /api/chat validates messages and calls OpenAI Chat Completions with a strict JSON schema containing reply and exerciseId. Only IDs from the actual library are accepted. The default personality prompt includes compassionate responses and urgent real-world support guidance. Live model responses require a configured key and have not been tested without one.

## Behavior

- Breathing uses requestAnimationFrame and performance.now as one source for character scale, phase, countdown, and progress.
- Sessions automatically pause on hidden browser tabs. Pause/resume retains position; restart resets the clock. Only completed sessions are recorded.
- Sound is an optional quiet generated phase chime, without external audio assets.
- Mood history, session history, preferences and a journal note use account-scoped localStorage; these remain device-local. Existing anonymous history is attached to the first local account. Achievements derive from saved session history.
- Account entry uses an email/password form backed by D1. This replaces the earlier local simulated ChatGPT sign-in flow; the hosting platform access boundary remains in place. Passwords use salted scrypt hashes (N=32768, r=8, p=3). Sessions use random tokens in HttpOnly SameSite=Lax cookies, with hashes stored in D1, seven-day expiry, and Secure cookies in production. Auth mutations enforce same-origin requests and login/signup attempts are rate-limited. Preferred name and reason are stored per authenticated user in D1. The header shows a daily streak derived from local mood and completed session history. A day counts once; yesterday’s streak remains active until today is missed.
- Conversations remain in memory, not localStorage. Typed messages go to the AI provider only when a server key is configured and the user sends them.
- Fonts are loaded from Google Fonts; rounded system fallbacks apply offline. All character illustrations are original SVG components.

## Design references

Mobbin's public page was accessible; the app library required sign-in. Official Headspace and Finch pages and the user's two supplied images informed the hierarchy, solid-color cards, and companion-first approach. The artwork is original.

## Validation

TypeScript and production build passed. Pure timing checks passed all five patterns' boundaries, countdowns, scale continuity, and cycle reset. Browser QA covered mood check-in, session start and pause/resume, and responsive layouts. AI missing-key behavior was verified; live AI responses require a key.

The app uses Next.js-compatible React/TypeScript routes through the supplied Vinext/Cloudflare Sites runtime, Tailwind CSS and CSS animation.

## Local profile database

The manifest declares D1 binding DB. Generate future schema changes with npm run db:generate. After building, apply the initial migration locally with:

```sh
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_married_eternals.sql
```

Hosted migrations are applied by Sites during publication. No live deployment has been verified.

Apply drizzle/0001_bright_kronos.sql after the initial migration using the same local D1 command. Email ownership verification and password-reset email delivery are not configured. Email addresses are used for login only. Local test accounts were removed after validation.

## Saved snapshot

This backup includes the latest typography, layout, palette and illustration refinements. TypeScript and the web production build passed after those changes. Browser visual verification of that final polish was interrupted before this GitHub backup request. The iOS Xcode project is in ios/; see its README for the native build limitations and TestFlight setup. No secrets, local accounts, database files, or dependency/build caches are included.
