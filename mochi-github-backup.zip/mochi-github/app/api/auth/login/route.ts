import {authenticate} from '../../../../lib/auth';
export const dynamic='force-dynamic';
export async function POST(request:Request){return authenticate(request,'login')}
