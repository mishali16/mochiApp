import {endSession,sameOrigin,noStore} from '../../../../lib/auth';
export const dynamic='force-dynamic';
export async function POST(request:Request){if(!sameOrigin(request))return Response.json({error:'Please use the app to log out.'},{status:403});return Response.json({ok:true},{headers:{...noStore,'Set-Cookie':await endSession(request)}})}
