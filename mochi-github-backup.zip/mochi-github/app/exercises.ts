export const exercises=[
{id:'box',name:'box breathing',description:'find your balance',color:'#B8A0E5',kind:'square',mood:'happy',phases:[['breathe in',4],['hold',4],['breathe out',4],['hold',4]]},
{id:'478',name:'4–7–8 breathing',description:'slow everything down',color:'#F4A475',kind:'blob',mood:'sleepy',phases:[['breathe in',4],['hold',7],['breathe out',8]]},
{id:'calm',name:'calm breathing',description:'let the tension go',color:'#A9D5BC',kind:'blob',mood:'happy',phases:[['breathe in',4],['breathe out',6]]},
{id:'equal',name:'equal breathing',description:'find your rhythm',color:'#F3CC58',kind:'blob',mood:'excited',phases:[['breathe in',5],['breathe out',5]]},
{id:'gentle',name:'gentle breathing',description:'start small',color:'#A1CDE3',kind:'blob',mood:'sleepy',phases:[['breathe in',3],['breathe out',4]]}
] as const;
export type Exercise=typeof exercises[number];
export function getFrame(ex:Exercise,elapsed:number){const cycle=ex.phases.reduce((n,p)=>n+p[1],0);let t=elapsed%cycle;let i=0;while(t>=ex.phases[i][1]&&i<ex.phases.length-1){t-=ex.phases[i][1];i++}const [label,duration]=ex.phases[i];const f=(1-Math.cos(Math.PI*t/duration))/2;const scale=label==='breathe in'?.75+.4*f:label==='breathe out'?1.15-.4*f:i===1?1.15:.75;return {label,count:Math.max(1,Math.ceil(duration-t)),scale,index:i};}
